// function formatRupiah(num) {
//     return "Rp " + num.toLocaleString("id-ID");
//   }
  
//   // Ambil ringkasan dari localStorage (diset di cart.js)
//   document.addEventListener("DOMContentLoaded", () => {
//     const items = localStorage.getItem("cart_total_items");
//     const price = localStorage.getItem("cart_total_price");
  
//     document.getElementById("summaryItems").textContent = items || 0;
//     document.getElementById("summaryPrice").textContent = price ? formatRupiah(parseInt(price)) : "Rp 0";
//   });
  
//   // Handle submit
//   document.getElementById("paymentForm").addEventListener("submit", e => {
//     e.preventDefault();
//     alert("Pembayaran berhasil diproses! 🎉");
//   });
  

function formatRupiah(num) {
    return "Rp " + num.toLocaleString("id-ID");
  }
  
  async function loadOrder() {
    const params = new URLSearchParams(window.location.search);
    const orderId = params.get("orderId");
  
    if (!orderId) return;
  
    const res = await fetch("http://localhost:3000/api/order/" + orderId);
    const data = await res.json();
  
    if (!data.success) {
      document.getElementById("orderDetails").innerHTML = "<p>Order tidak ditemukan</p>";
      return;
    }
  
    let html = `
      <p>Order ID: <strong>${data.order.id}</strong></p>
      <p>Status: <strong>${data.order.status}</strong></p>
      <h3>Item:</h3>
      <ul>
        ${data.items.map(it => `<li>${it.name} x${it.qty} - ${formatRupiah(it.price * it.qty)}</li>`).join("")}
      </ul>
      <h3>Total: ${formatRupiah(data.order.total_price)}</h3>
      <button onclick="alert('Simulasi bayar sukses!')">Bayar Sekarang</button>
    `;
  
    document.getElementById("orderDetails").innerHTML = html;
  }
  
  loadOrder();
  