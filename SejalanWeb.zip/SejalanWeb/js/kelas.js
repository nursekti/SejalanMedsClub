console.log("🔥 kelas.js loaded");

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBMJX0eWB1gUyvBUzeUSYt05XX-lD33-js",
  authDomain: "sejalan-884bc.firebaseapp.com",
  projectId: "sejalan-884bc",
  storageBucket: "sejalan-884bc.firebasestorage.app",
  messagingSenderId: "768730225727",
  appId: "1:768730225727:web:fbb9dcef53b8ea1f0a2c8a",
  measurementId: "G-E522147QHB"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function loadKelas() {
  const container = document.getElementById("courses");
  container.innerHTML = `<p style="text-align:center;color:#6b7280;">Memuat data...</p>`;

  try {
    const querySnapshot = await getDocs(collection(db, "kelas"));
    container.innerHTML = "";

    if (querySnapshot.empty) {
      container.innerHTML = `<p style="text-align:center;color:#6b7280;">Belum ada kelas tersedia.</p>`;
      return;
    }

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      const harga = data.harga ? data.harga.toLocaleString("id-ID") : "0";

      const card = document.createElement("div");
      card.className = "course-card";
      card.innerHTML = `
        <div class="badge">${data.type || "Kelas"}</div>
        <div class="card-body">
          <h4>${data.kelas}</h4>
          <p class="muted">${data.deskripsi}</p>
        </div>
        <div class="card-footer">
          <div class="price">Rp ${harga}</div>
          <div class="actions">
            <button class="btn-primary">Lihat Detail</button>
          </div>
        </div>
      `;

      container.appendChild(card);
    });
  } catch (err) {
    console.error("❌ Gagal memuat data kelas:", err);
    container.innerHTML = `<p style="text-align:center;color:red;">Gagal memuat data kelas.</p>`;
  }
}

loadKelas();
