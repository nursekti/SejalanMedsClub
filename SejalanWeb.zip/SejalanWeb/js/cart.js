// function formatRupiah(num) {
//     return "Rp " + num.toLocaleString("id-ID");
//   }
  
//   function updateSummary() {
//     let totalItems = 0;
//     let totalPrice = 0;
  
//     document.querySelectorAll(".cart-item").forEach(item => {
//       const check = item.querySelector(".cart-check");
//       const qtyInput = item.querySelector(".qty-control input");
//       const qty = parseInt(qtyInput.value) || 0;
//       const price = parseInt(item.dataset.price);
  
//       // update harga satuan
//       const priceLabel = item.querySelector(".price-label");
//       priceLabel.textContent = "Harga: " + formatRupiah(price);
  
//       // update subtotal per produk
//       const itemTotal = price * qty;
//       const itemTotalEl = item.querySelector(".item-total");
//       itemTotalEl.textContent = "Subtotal: " + formatRupiah(itemTotal);
  
//       // hanya hitung kalau dichecklist
//       if (check.checked) {
//         totalItems += qty;
//         totalPrice += itemTotal;
//       }
//     });
  
//     // update ringkasan
//     document.getElementById("totalItems").textContent = totalItems;
//     document.getElementById("totalPrice").textContent = formatRupiah(totalPrice);
//   }
  
//   // event listener utk checkbox
//   document.querySelectorAll(".cart-check").forEach(chk => {
//     chk.addEventListener("change", updateSummary);
//   });
  
//   // event listener utk tombol +/-
//   document.querySelectorAll(".qty-control button").forEach(btn => {
//     btn.addEventListener("click", e => {
//       const input = e.target.parentElement.querySelector("input");
//       let val = parseInt(input.value);
//       if (e.target.textContent === "+") val++;
//       if (e.target.textContent === "-" && val > 0) val--; // minimal 0
//       input.value = val;
//       updateSummary();
//     });
//   });
  
//   // event listener utk input manual qty
//   document.querySelectorAll(".qty-control input").forEach(inp => {
//     inp.addEventListener("input", updateSummary);
//   });
  
//   // set awal
//   updateSummary();
  
//   document.getElementById("checkoutBtn").addEventListener("click", () => {
//     window.location.href = "payment.html";
//   });  

function formatRupiah(num) {
  return "Rp " + num.toLocaleString("id-ID");
}

function updateSummary() {
  let totalItems = 0;
  let totalPrice = 0;

  document.querySelectorAll(".cart-item").forEach(item => {
    const check = item.querySelector(".cart-check");
    const qty = parseInt(item.querySelector(".qty-control input").value) || 0;
    const price = parseInt(item.dataset.price);

    const priceLabel = item.querySelector(".price-label");
    priceLabel.textContent = "Harga: " + formatRupiah(price);

    const itemTotal = price * qty;
    const itemTotalEl = item.querySelector(".item-total");
    itemTotalEl.textContent = "Subtotal: " + formatRupiah(itemTotal);

    if (check.checked) {
      totalItems += qty;
      totalPrice += itemTotal;
    }
  });

  document.getElementById("totalItems").textContent = totalItems;
  document.getElementById("totalPrice").textContent = formatRupiah(totalPrice);
}

// event listener qty
document.querySelectorAll(".qty-control button").forEach(btn => {
  btn.addEventListener("click", e => {
    const input = e.target.parentElement.querySelector("input");
    let val = parseInt(input.value);
    if (e.target.textContent === "+") val++;
    if (e.target.textContent === "-" && val > 0) val--;
    input.value = val;
    updateSummary();
  });
});

document.querySelectorAll(".qty-control input").forEach(inp => {
  inp.addEventListener("input", updateSummary);
});

document.querySelectorAll(".cart-check").forEach(chk => {
  chk.addEventListener("change", updateSummary);
});

// tombol checkout
document.getElementById("checkoutBtn").addEventListener("click", async () => {
  const items = [];
  document.querySelectorAll(".cart-item").forEach(item => {
    if (item.querySelector(".cart-check").checked) {
      const productName = item.querySelector("h3").textContent;
      const qty = parseInt(item.querySelector(".qty-control input").value);
      const price = parseInt(item.dataset.price);
      items.push({ productName, qty, price });
    }
  });

  const res = await fetch("http://localhost:3000/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items })
  });

  const data = await res.json();
  if (data.success) {
    window.location.href = "payment.html?orderId=" + data.orderId;
  }
});

updateSummary();
