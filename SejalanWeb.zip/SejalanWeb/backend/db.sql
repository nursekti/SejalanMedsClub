CREATE DATABASE sejalan_meds;
USE sejalan_meds;

-- tabel produk
CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  price INT,
  image_url VARCHAR(255)
);

INSERT INTO products (name, price, image_url) VALUES
('Buku Saku Kedokteran', 120000, 'assets/book1.jpg'),
('Stetoskop Premium', 450000, 'assets/stetoskop.jpg');

-- tabel orders
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total_price DECIMAL(10,2),
  status ENUM('pending','paid','canceled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- tabel order_items
CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT,
  qty INT,
  price INT,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);
