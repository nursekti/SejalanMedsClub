// server.js (pakai CommonJS)
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");

const app = express();
app.use(cors());
app.use(express.json());

// koneksi ke MySQL
(async () => {
  const db = await mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "sejalan_meds"
  });

  // checkout → simpan order
  app.post("/api/checkout", async (req, res) => {
    const { items } = req.body;

    let totalPrice = 0;
    items.forEach(it => totalPrice += it.qty * it.price);

    const [orderResult] = await db.execute(
      "INSERT INTO orders (user_id, total_price, status) VALUES (?,?,?)",
      [1, totalPrice, "pending"]
    );
    const orderId = orderResult.insertId;

    for (let it of items) {
      const [rows] = await db.execute(
        "SELECT id FROM products WHERE name = ? LIMIT 1",
        [it.productName]
      );
      const productId = rows.length ? rows[0].id : null;

      await db.execute(
        "INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?,?,?,?)",
        [orderId, productId, it.qty, it.price]
      );
    }

    res.json({ success: true, orderId });
  });

  // ambil data order
  app.get("/api/order/:id", async (req, res) => {
    const orderId = req.params.id;

    const [orders] = await db.execute(
      "SELECT * FROM orders WHERE id = ?",
      [orderId]
    );

    if (!orders.length) return res.json({ success: false });

    const order = orders[0];
    const [items] = await db.execute(
      `SELECT oi.qty, oi.price, p.name 
       FROM order_items oi 
       JOIN products p ON oi.product_id = p.id 
       WHERE oi.order_id = ?`,
      [orderId]
    );

    res.json({ success: true, order, items });
  });

  app.listen(3000, () => console.log("✅ API jalan di http://localhost:3000"));
})();
